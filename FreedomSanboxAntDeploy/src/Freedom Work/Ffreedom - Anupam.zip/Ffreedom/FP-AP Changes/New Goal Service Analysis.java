private Double applyAllocatedAssetsOnGoalAmount(GoalMappingBean bean ,Goal_Profile__c startingProfile,Double targetAmount ,Integer currYear ,Integer goalYear,String savingType,Integer goalFrequency) 
{
    Double remainingAmount, assetMaturedAmount, growthRate ,pvAmount ,rate;
   Integer assetStartYear,maturityYear;
    try 
    {	
		for(GoalMappingBean.GoalAssetMappingBean goalAssetMappingBean :  bean.goalAssetMappingBeanList)
		{
			remainingAmount = goalAssetMappingBean.remainingAmount;
			// maturity year of asset allocated to perticular goal
			maturityYear = goalAssetMappingBean.endYear;
			// start year of asset allocated to perticular goal
			assetStartYear = goalAssetMappingBean.startYear;
			// This condition should have check on Investment asset
			if('InvAsset'.equals(goalAssetMappingBean.assetAssociationType) && (goalAssetMappingBean.startYear == null))
			{ 
				assetStartYear = System.today().year();
				maturityYear =  goalYear;
			}
                  
			if(targetAmount > 0)
			{
				if(isAssetAllocationStartYear)
				{
					isAssetAllocationStartYear = false;
					iAssetAllocationStartYear = goalYear;
				}
				/*Niket 
				  Summary : Need this change for the Goal Calculation, Which need to change because we need to perform to different logics 
					  for 1] if assets align to goal with action "To be grown till maturity and continue saving"
						  2] if assets align to goal with action "To be grown till maturity but stop saving more"
						  
						  Note : 1] "Action1" is a Custome setting Contains the value => To be grown till maturity and continue saving
								 2] "Action2" is a Custome setting Contains the value => To be grown till maturity but stop saving more
								3] "Action3" is a Custome setting Contains the value => Liquidate (Align to goal)
								 4] "Action4" is a Custome setting Contains the value => Liquidate (Sell)
								 5] "Action5" is a Custome setting Contains the value => Hold ==>Hold (Align to goal)
								 6] "Action6" is a Custome setting Contains the value => Sell ==>Liquidate (Align to goal)
				*/
                     
				if(Allocation_Action__c.getInstance('Action1').Action__c.equalsIgnoreCase(goalAssetMappingBean.action) ||
						   Allocation_Action__c.getInstance('Action2').Action__c.equalsIgnoreCase(goalAssetMappingBean.action))
				{
					AssetAllocationService objAssetAllocationService = new AssetAllocationService();
					GoalInsuranceAssociation__c objGoalInsuranceAssociation;
					if(goalAssetMappingBean.assetAssociationType.equalsIgnoreCase('Insurance'))
						objGoalInsuranceAssociation = (GoalInsuranceAssociation__c)goalAssetMappingBean.assetObj;
						
					if(remainingAmount == null) 
					{ 
						// calculate Matured amount and grow if needed
						if(maturityYear > goalYear) 
						{
							continue;
						}
						
						if(Allocation_Action__c.getInstance('Action2').Action__c.equalsIgnoreCase(goalAssetMappingBean.action) && 
							  goalAssetMappingBean.assetAssociationType.equalsIgnoreCase('Insurance'))
						{
							/*Manasi
								 1. Maturity amount of Insurance is wrong when we select Action2
								 2. Calculation of current value: 
									If Surender amount is not null then fetch it else runtime calculate the value.  
							*/
							if(insuranceMap.containsKey(objGoalInsuranceAssociation.Insurance__C))
							{
								Insurance__c objInsurance =insuranceMap.get(objGoalInsuranceAssociation.Insurance__C);
								Double dblOneInstallmentPremiumAmount = 0;
								
								/*1.Here 2nd parameter of calculateCompound function is (Maturity year - Current Year) .
								  2.Because we are condering current amount of insurance.
								  3.In case of other asset classes,that parameter will be (Maturity year - Asset start year)
								  4.Reason :If we create FD and Insurance, 2 years before with amount 5000 each, 
										then current value of FD will be 5000 and Insurance will be 5500 */
								if((maturityYear - System.today().year()) > 0)
									  assetMaturedAmount = FinancialUtil.calculateCompound(goalAssetMappingBean.allocatedAmount,( maturityYear - System.today().year()),goalAssetMappingBean.growthRate);
								else
									  assetMaturedAmount = goalAssetMappingBean.allocatedAmount;
							}
                        }
						else
						{
							/** Eternus Solutions       **/
							/** Author  : Manasi Ranade **/
							/** Issue Id: FS0164      **/
							/** Date    : 27/9/2011    **/
							/** Purpose : Fetch the maturity amount from goalMappingBean object
							/****************************************************/
							if(goalAssetMappingBean.assetAssociationType.equalsIgnoreCase('InvAssetFixedIncome'))
							{
								assetMaturedAmount = goalAssetMappingBean.maturityAmount;
                                maturityYear = goalAssetMappingBean.endYear;
                            }
                                else
							{
								if((maturityYear - System.today().year()) > 0)
									assetMaturedAmount = FinancialUtil.calculateCompound(goalAssetMappingBean.allocatedAmount,( maturityYear - Date.today().year()),goalAssetMappingBean.growthRate);
								else
									assetMaturedAmount = goalAssetMappingBean.allocatedAmount;
							}
						}
						if(Allocation_Action__c.getInstance('Action2').Action__c.equalsIgnoreCase(goalAssetMappingBean.action)) 
						{
							if((maturityYear) < goalYear)
							{
								rate = FinancialUtil.calculateRate(FinancialUtil.calculateFutureValue(100, rateList,goalYear - maturityYear),100,goalYear - maturityYear);
								assetMaturedAmount = FinancialUtil.calculateCompound(assetMaturedAmount,goalYear - maturityYear,rate);
								//assetMaturedAmount = FinancialUtil.calculateCompound(assetMaturedAmount,maturityYear - goalYear,rate);
							}
						}
						/*
							Modified By : Niket Chandane
							Modified On : 9 june 2011
							Summary       : The growthRateInAnnualContribution and the growthRate is considered in the 
											   calculation only when "To be grown till maturity and continue saving" is get
											   selected on the asset allocation page. This calculation can be seen on the 
											   Allocated Goals calculation's target amount.
						*/
                              
						else if(Allocation_Action__c.getInstance('Action1').Action__c.equalsIgnoreCase(goalAssetMappingBean.action)) 
						{
							/** Eternus Solutions   **/
							/** Author  : Manasi Ranade **/
							/** Issue Id: FS0118      **/
							/** Date    : 22/08/2011   **/
							/** Purpose : Code to calculate maturity amount of insurance.
							/****************************************************/ 
							if(goalAssetMappingBean.assetAssociationType.equalsIgnoreCase('Insurance'))
							{
								/*AssetAllocationService objAssetAllocationService = new AssetAllocationService();
								GoalInsuranceAssociation__c objGoalInsuranceAssociation = (GoalInsuranceAssociation__c)goalAssetMappingBean.assetObj;*/
								if(insuranceMap.containsKey(objGoalInsuranceAssociation.Insurance__C))
								{
									/** Eternus Solutions       **/
									/** Author  : Manasi Ranade **/
									/** Issue Id: 00001622     **/
									/** Date    : 8/5/2012           **/
									/** Purpose : Commented following part.
													  No need to overwrite the value of goalAssetMappingBean.allocatedAmount
													  It is set in function getAssociatedInsuranceAssets
									/****************************************************/
									/** Eternus Solutions       **/
									/** Author  : Manasi Ranade **/
									/** Issue Id: 00001663     **/
									/** Date    : 31/5/2012           **/
									/** Purpose : Uncommented following part.
													  For Action1 calculate the maturity amount and then apply progressive Rate.
									/****************************************************/
									Insurance__c objInsurance =insuranceMap.get(objGoalInsuranceAssociation.Insurance__C);
									Integer iTenureOfInsurance = Integer.valueOf(objInsurance.Tenure_of_Insurance__c);
									Date dtEndDate =  objInsurance.Commencement_Date__c;
									dtEndDate = dtEndDate.addYears(iTenureOfInsurance);
									Integer totalPeriodInYears =  dtEndDate.year() - objInsurance.Commencement_Date__c.year();
										
									assetMaturedAmount = objAssetAllocationService.GetInsuranceAmountForPeriod(objInsurance, 
																												totalPeriodInYears, 
																												Double.valueOf(objInsurance.Premium_Amount_Rs__c));
									Double dblAllocated = 0;
									if(objGoalInsuranceAssociation.Allocated__c != null)
									{
										String strAllocatedValue = string.valueof(objGoalInsuranceAssociation.Allocated__c);
										if(strAllocatedValue != '')
										{
											dblAllocated = double.valueof(strAllocatedValue);
											if(dblAllocated > 0)
												assetMaturedAmount = assetMaturedAmount * (dblAllocated / 100);
										}
									}
                                }
                                else
                                    	assetMaturedAmount = 0;
                             }
							else
							{
								//Maturity amount will get calculated from Current year to Maturity year. So replaced (maturityYear - assetStartYear) parameter by (maturityYear - Date.today().year())
								//Manasi FS0305
								/** Eternus Solutions       **/
								/** Author  : Manasi Ranade **/
								/** Issue Id: FS0305      **/
								/** Date    : 21/11/2011   **/
								/** Purpose : Fetch the Growth rate in anual contribution for current asset
								/****************************************************/
								 
								Double dblgrowthRateInAnnualContribution = 0;
								if(goalAssetMappingBean.growthRateInAnnualContribution != null)
								{
									dblgrowthRateInAnnualContribution = goalAssetMappingBean.growthRateInAnnualContribution ;
									//dblgrowthRateInAnnualContribution = dblgrowthRateInAnnualContribution / 100;
								}
								 
								if((maturityYear - Date.today().year()) > 0)
								{
									//dblAnnualExpextedgrowthRate
									assetMaturedAmount = FinancialUtil.calCompoundForAssetGrowth(goalAssetMappingBean.allocatedAmount,(maturityYear - Date.today().year()),goalAssetMappingBean.growthRate,goalAssetMappingBean.annualContribution,dblgrowthRateInAnnualContribution,goalAssetMappingBean.description);
								}
								else
									 assetMaturedAmount = goalAssetMappingBean.allocatedAmount;
                                            
								if(goalAssetMappingBean.assetAssociationType.equalsIgnoreCase('InvAssetFixedIncome'))
								{
								
									assetMaturedAmount = goalAssetMappingBean.maturityAmount;
									maturityYear = goalAssetMappingBean.endYear; 
								}
                                                              
                            }
                                  
                                if(maturityYear < goalYear)
                                {
                                        rate = FinancialUtil.calculateRate(FinancialUtil.calculateFutureValue(100, rateList,goalYear - maturityYear),100,goalYear - maturityYear);
                                        assetMaturedAmount = FinancialUtil.calculateCompound(assetMaturedAmount,goalYear - maturityYear,rate);
                                }
                            }
                            remainingAmount = assetMaturedAmount;
                            goalAssetMappingBean.goalYearValue = assetMaturedAmount;
                            goalAssetMappingBean.remainingAmount = remainingAmount;
                        }
                        
                        if(remainingAmount > 0)
                        {
                        	if(targetAmount >= remainingAmount) 
                            {
                            	targetAmount = targetAmount - remainingAmount;
                                /** Eternus Solutions       **/
                                /** Author  : Manasi Ranade **/
                                /** Issue Id: 00001610     **/
                                /** Date    : 27/4/2012           **/
                                /** Purpose : Function to print the Goal Year and Related sequence of allocation
                                /****************************************************/
                                   isAssetAllocationStartYear = true;
                                   PrintSequence(goalYear, goalAssetMappingBean.description, goalAssetMappingBean.entityName);
                                   goalAssetMappingBean.remainingAmount = 0;
                            }
                            else 
                            {
                                Double iTempTargetAmount = targetAmount - remainingAmount;
                                remainingAmount = remainingAmount - targetAmount;
                               
                                goalAssetMappingBean.remainingAmount = calculateUpdatedRemainingAmount(remainingAmount,goalFrequency);
                               
                                targetAmount = iTempTargetAmount;
                                
                            	if(targetAmount < 0 && bean.goalEndYear == goalYear)
                                   	  PrintSequence(goalYear,goalAssetMappingBean.description,goalAssetMappingBean.entityName);
                            }
                        }
                    }
                    
                    else if ((Allocation_Action__c.getInstance('Action3').Action__c.equalsIgnoreCase(goalAssetMappingBean.action)))
                                   //||(Allocation_Action__c.getInstance('Action6').Action__c.equalsIgnoreCase(goalAssetMappingBean.action))) 
                    {
                    	if(remainingAmount == null)
                       	{
	                   		if(remainingAmount == null) 
	                       	{
	                          	remainingAmount = goalAssetMappingBean.allocatedAmount;
	                          	goalAssetMappingBean.goalYearValue =  remainingAmount;
	                       	}
	                       	if(remainingAmount == 0) 
	                       	{
	                          continue;
	                       	}
	                       
                           	if('InvAsset'.equals(goalAssetMappingBean.assetAssociationType) ||
                      			 'Asset'.equals(goalAssetMappingBean.assetAssociationType) || 
                       			 'InvAssetFixedIncome'.equals(goalAssetMappingBean.assetAssociationType) ) 
                            {
                            	//If selected asset is 'Real Estate Assets' then grow it by 10%
                              	//goalAssetMappingBean.asset__r.RecordType.Name.
                              
                              	if(Date.today().year() < goalYear)
                              	{   
                                	growthRate = FinancialUtil.calculateRate(FinancialUtil.calculateFutureValue(100, rateList, goalYear - currYear), 100, (goalYear- currYear));
                                  	assetMaturedAmount = FinancialUtil.calculateCompound(goalAssetMappingBean.allocatedAmount, (goalYear - currYear ), growthRate);
                                  	remainingAmount = assetMaturedAmount;
	                              	goalAssetMappingBean.goalYearValue = assetMaturedAmount;
	                              	goalAssetMappingBean.remainingAmount = remainingAmount;
                              	}
                                      
                            }
                            else if('Insurance'.equals(goalAssetMappingBean.assetAssociationType)) 
                            { 
                            	// Consider total Asset value here. Don't need to grow
                               	if(Date.today().year() < goalYear)
                               	{
                                	//To calculate current value of insurance
                                  	AssetAllocationService objAssetAllocationService = new AssetAllocationService();
                                    GoalInsuranceAssociation__c objGoalInsuranceAssociation;
                                    objGoalInsuranceAssociation = (GoalInsuranceAssociation__c)goalAssetMappingBean.assetObj;  
                                     
                                    Insurance__c objInsurance =insuranceMap.get(objGoalInsuranceAssociation.Insurance__C);
                                    Double dblOneInstallmentPremiumAmount = 0;
                                    if(!objInsurance.Premium_Frequency__c.equals('One Time Premium'))
                                    	dblOneInstallmentPremiumAmount = objInsurance.Premium_Amount_Rs__c;
                                    	
                                    Integer iTenureOfInsurance = Integer.valueOf(objInsurance.Tenure_of_Insurance__c);
                                    Integer iMaturityYear = iTenureOfInsurance + objInsurance.Commencement_Date__c.year();
                                    Integer iCurrentYearForCalculation = 0;
                                    
                                 	if(Date.today().year() > iMaturityYear)
                                        iCurrentYearForCalculation = iMaturityYear;
                                 	else
                                        iCurrentYearForCalculation = Date.today().year();
                                        
                                    Integer totalPeriodInYears =  iCurrentYearForCalculation - objInsurance.Commencement_Date__c.year();//
                                    /** Eternus Solutions       **/
                                    /** Author  : Manasi Ranade **/
                                    /** Issue Id: 00001622     **/
                                    /** Date    : 8/5/2012           **/
                                    /** Purpose : Commented following part.
                                                   No need to overwrite the value of goalAssetMappingBean.allocatedAmount
                                                   It is set in function getAssociatedInsuranceAssets
                                    /****************************************************/
                                    /*if(objInsurance.Surrender_Cash_Value__c == null)
                                           goalAssetMappingBean.allocatedAmount = objAssetAllocationService.GetInsuranceAmountForPeriod(objInsurance,totalPeriodInYears, dblOneInstallmentPremiumAmount);
	                                  else
	                                       goalAssetMappingBean.allocatedAmount = objInsurance.Surrender_Cash_Value__c;*/
	                                //1.Here 2nd parameter of calculateCompound function is (Maturity year - Current Year) .
                                    //2.Because we are condering current amount of insurance.
                                    //3.In case of other asset classes,that parameter will be (Maturity year - Asset start year)
                                    //4.Reason :If we create FD and Insurance, 2 years before with amount 5000 each, 
                                    //   then current value of FD will be 5000 and Insurance will be 5500
                                    //if statent
                                    growthRate = FinancialUtil.calculateRate(FinancialUtil.calculateFutureValue(100, rateList, goalYear - currYear), 100,(goalYear- currYear));
                                    
                                    assetMaturedAmount = FinancialUtil.calculateCompound(goalAssetMappingBean.allocatedAmount, (goalYear - currYear ), growthRate);
                                    //(goalYear - currYear ), 10);
                                    //pvAmount = FinancialUtil.calculatePrincipal(targetAmount,(goalYear - currYear),growthRate);
                                    remainingAmount = assetMaturedAmount;
                                   	goalAssetMappingBean.goalYearValue = assetMaturedAmount;
                                    goalAssetMappingBean.remainingAmount = remainingAmount;
                               	} 
                            }
                       	}
                        if(remainingAmount > 0) 
                        {
                        	if(targetAmount >= remainingAmount) 
                        	{
                            	targetAmount = targetAmount - remainingAmount;
	                            /** Eternus Solutions       **/
	                            /** Author  : Manasi Ranade **/
	                            /** Issue Id: 00001610     **/
	                            /** Date    : 27/4/2012           **/
	                            /** Purpose : Function to print the Goal Year and Related sequence of allocation
	                            /****************************************************/
                                isAssetAllocationStartYear = true;
                                PrintSequence(goalYear,goalAssetMappingBean.description,goalAssetMappingBean.entityName);
                                goalAssetMappingBean.remainingAmount = 0;                    
                        	} 
                        	else 
                        	{
                            	//FS0168
                            	Double iTempTargetAmount =  targetAmount - remainingAmount;
                          		remainingAmount = remainingAmount - targetAmount;
                          		//goalAssetMappingBean.remainingAmount = remainingAmount;
                          		/** Eternus Solutions       **/
                             	/** Author  : Manasi Ranade **/
                             	/** Issue Id: 00001536     **/
                             	/** Date    : 6/3/2012           **/
                             	/** Purpose : Added goalFrequency parameter to the function calculateUpdatedRemainingAmount().
                                                   It will be usefull in calculation of surplus amount if Goal Frequency is greater than 1 */
                                                   
                             	goalAssetMappingBean.remainingAmount = calculateUpdatedRemainingAmount(remainingAmount,goalFrequency);
                          		//Prevoius code: It is commented to display negative target amounts
                          		//targetAmount = 0;
                          		
                          		targetAmount = iTempTargetAmount;
                          		if(targetAmount < 0 && bean.goalEndYear == goalYear)
                          			PrintSequence(goalYear,goalAssetMappingBean.description,goalAssetMappingBean.entityName);
                        	}
                        }
                       	/*
                       	if(remainingAmount > 0) {
                                  if(targetAmount >= remainingAmount) {
                                      targetAmount = targetAmount - remainingAmount;
                                      goalAssetMappingBean.remainingAmount = 0;                    
                                  } else {
                                        //FS0168
                                        Double iTempTargetAmount =  targetAmount - remainingAmount;
                                      remainingAmount = remainingAmount - targetAmount;
                                      //goalAssetMappingBean.remainingAmount = remainingAmount;
                                      //00001536
                                                             goalAssetMappingBean.remainingAmount = calculateUpdatedRemainingAmount(remainingAmount,goalFrequency);
                                      
                                      //Prevoius code: It is commented to display negative target amounts
                                      //targetAmount = 0;
                                      targetAmount = iTempTargetAmount; 
                                  }
                              }
                       
                        */
                    }
                    /*Niket
                    /*When Assets are align to Goal with Action Liquidate (Sell)*/
                    
                    else if(Allocation_Action__c.getInstance('Action4').Action__c.equalsIgnoreCase(goalAssetMappingBean.action))
                    {  
                    	//Liquidate (Sell)
                        if(remainingAmount == null) 
                        {
                        	remainingAmount = goalAssetMappingBean.allocatedAmount;
                            goalAssetMappingBean.goalYearValue =  remainingAmount;
                        }
                        if(remainingAmount == 0) 
                        {
                        	continue;
                        }
                        if(remainingAmount > 0) 
                        {
	                        if(targetAmount >= remainingAmount) 
	                        {
	                               targetAmount = targetAmount - remainingAmount;
	                               goalAssetMappingBean.remainingAmount = 0;                    
	                        } 
	                        else 
	                        {
                                //FS0168
                            	Double iTempTargetAmount = targetAmount - remainingAmount;
                                /** Eternus Solutions       **/
                                /** Author  : Manasi Ranade **/
                                /** Issue Id: 00001610     **/
                                /** Date    : 27/4/2012           **/
                                /** Purpose : Function to print the Goal Year and Related sequence of allocation
                                /****************************************************/
                                isAssetAllocationStartYear = true;
                                PrintSequence(goalYear,goalAssetMappingBean.description,goalAssetMappingBean.entityName);
                                remainingAmount = remainingAmount - targetAmount;
                               	//goalAssetMappingBean.remainingAmount = remainingAmount;
                              	 /** Eternus Solutions       **/
                               	/** Author  : Manasi Ranade **/
                               	/** Issue Id: FS0337      **/
                               	/** Date    : 6/12/2011    **/
                               	/** Purpose : Added function to calculate the updated values of remaining amount.
                                                     It should increase by 8% every year
                               	/****************************************************/
                               	/** Eternus Solutions       **/
                               	/** Author  : Manasi Ranade **/
                               	/** Issue Id: 00001536     **/
                               	/** Date    : 6/3/2012           **/
                               	/** Purpose : Added goalFrequency parameter to the function calculateUpdatedRemainingAmount().
                                                     It will be usefull in calculation of surplus amount if Goal Frequency is greater than 1
                               	/****************************************************/
                               	goalAssetMappingBean.remainingAmount = calculateUpdatedRemainingAmount(remainingAmount,goalFrequency);
                               	//targetAmount = 0;
                               	targetAmount = iTempTargetAmount;   
	                        }
                        }                                                
                    }
                    
                    /*When Assets are align to Goal with Action Hold*/
                    else if((Allocation_Action__c.getInstance('Action5').Action__c.equalsIgnoreCase(goalAssetMappingBean.action))) 
                    {
                    	Boolean blnIsApplicable = true;
                     	/** Eternus Solutions       **/
                     	/** Author  : Manasi Ranade **/
                     	/** Issue Id: FS0166       **/
                     	/** Date    : 9/26/2011    **/
                     	/** Purpose : For Mutual Fund, 'Hold Align to Goal' and 'Liquidate Align To Goal' should work in same manner
                                                 So if selected action is Hold Align to Goal then dont execute the following code.
                                                It should execute the Liquidate Align To Goal related code 
                     	/****************************************************/
                     	if('InvAsset'.equals(goalAssetMappingBean.assetAssociationType))
                     	{
                        	/*AggregateResult  objAggrResult = (AggregateResult)goalAssetMappingBean.assetObj;
                              String strSelectedRecordType = String.valueOf(objAggrResult.get('recordTypeName'));
                              if('Mutual Fund'.equals(strSelectedRecordType))
                              {
                                     blnIsApplicable = false;
                              }
                            */
                            if(goalAssetMappingBean.Description.equals('Mutual Fund'))
                            {
                            	blnIsApplicable = false;
                            }
                     	}
                        //if(blnIsApplicable)
                        {
                        	//PrintSequence(goalYear,goalAssetMappingBean.description,goalAssetMappingBean.entityName);
                            if(remainingAmount == null)
                            {
                            	if(remainingAmount == null) 
                            	{
                             		//isAssetAllocationStartYear = true;
                             	 	//PrintSequence(goalYear,goalAssetMappingBean.description,goalAssetMappingBean.entityName);
                                 	remainingAmount = goalAssetMappingBean.allocatedAmount;
                                 	goalAssetMappingBean.goalYearValue =  remainingAmount;
                            	}
                                if(remainingAmount == 0) 
                                {
									continue;
                                }
                                if('Asset'.equals(goalAssetMappingBean.assetAssociationType)) 
                                {
	                            	//If selected asset is 'Real Estate Assets' then grow it by 10%
	                             	//goalAssetMappingBean.asset__r.RecordType.Name.
	                             	if(Date.today().year() < goalYear)
                                    { 
                                    	if('Asset'.equals(goalAssetMappingBean.assetAssociationType))
                                    	{
                                        	GoalAssetAssociation__c objGoalAssetAssociation = (GoalAssetAssociation__c)goalAssetMappingBean.assetObj;
                                            /*if(objGoalAssetAssociation.asset__r.RecordType.Name.equals('Real Estate Assets'))
                                                 growthRate = double.valueOf(Label.RealEastateGrowthRate);//10
                                              else //Previous logic for real eastate: consider 10 Growth rate*/
                                              
                                            if(objGoalAssetAssociation.asset__r.Expected_Growth_Rate__c != null)
                                                 growthRate = objGoalAssetAssociation.asset__r.Expected_Growth_Rate__c;
                                            else
                                            {
                                                 //growthRate = objGoalAssetAssociation.asset__r.Expected_Growth_Rate__c;
                                                 setInfoMessage('Please fill the Expected Growth Rate for ' + objGoalAssetAssociation.asset__r.RecordType.Name + ' assets.');
                                            } 
                                    	}
                                        else
                                        {
                                         	 growthRate = 10;
                                        }
                                                                     
                                        /* //Working code Manasi
                                           goalAssetMappingBean.goalYearValue = FinancialUtil.calculateCompound(goalAssetMappingBean.allocatedAmount,
                                           (goalYear - currYear ), growthRate);
                                           pvAmount = FinancialUtil.calculatePrincipal(targetAmount,(goalYear - currYear),growthRate);
                                           if(remainingAmount >= pvAmount) {
                                               remainingAmount = remainingAmount - pvAmount;
                                               goalAssetMappingBean.remainingAmount = remainingAmount;
                                               targetAmount = 0;
                                           }else {
                                               pvAmount = pvAmount - remainingAmount;
                                               targetAmount =  FinancialUtil.calculateCompound(pvAmount,(goalYear - currYear ), growthRate);
                                               goalAssetMappingBean.remainingAmount = 0;
                                           }*/
                                                   
                                        /** Eternus Solutions       **/
                                        /** Author  : Manasi Ranade **/
                                        /** Issue Id: 00001535     **/
                                        /** Date    : 6/3/2012           **/
                                        /** Purpose : 1. If EndYear is menssioned for the Asset, then consider it for calculation.
                                                               2. Asset will grow upto the given end year by its expected growth rate. After that asset will grow progressively.
                                                               Above functionality is done in the following code 
                                        /****************************************************/
                                        if(goalAssetMappingBean.endYear != null)
                                        {
                                        	if(goalYear >= goalAssetMappingBean.endYear)
                                            {
                                                                                  // Calculate the amount according to its Growth rate if End Year is mensioned
                                            	 if((goalAssetMappingBean.endYear - currYear) > 0)
                                                 	assetMaturedAmount = FinancialUtil.calculateCompound(goalAssetMappingBean.allocatedAmount,
                                                    													(goalAssetMappingBean.endYear - currYear), growthRate);
                                               	else
                                                    assetMaturedAmount = goalAssetMappingBean.allocatedAmount;
                                         	   	//Increase the amount progressively upto GoalYear
                                               	if((goalYear - goalAssetMappingBean.endYear) > 0)
                                               	{
                                               		rate = FinancialUtil.calculateRate(FinancialUtil.calculateFutureValue(100, rateList,goalYear - goalAssetMappingBean.endYear)
                                                                                                        ,100,goalYear - goalAssetMappingBean.endYear);
                                                	assetMaturedAmount = FinancialUtil.calculateCompound(assetMaturedAmount,goalYear - goalAssetMappingBean.endYear,rate);
                                            	}
                                            }
                                            else
                                            {
                                                assetMaturedAmount = 0;
                                            }
                                        }
                                     	else
                                     	{
                                        	assetMaturedAmount = FinancialUtil.calculateCompound(goalAssetMappingBean.allocatedAmount,
                         																			 (goalYear - currYear ), growthRate);
                                     	}
                                                              
                                        remainingAmount = assetMaturedAmount;
	                                    goalAssetMappingBean.goalYearValue = assetMaturedAmount;
	                                    goalAssetMappingBean.remainingAmount = remainingAmount;
                                           }
                                             
                                }
                                     else if('InvAsset'.equals(goalAssetMappingBean.assetAssociationType))
                                     {
                                             //If selected asset is 'Real Estate Assets' then grow it by 10%
                                             //goalAssetMappingBean.asset__r.RecordType.Name.
                                             
                                             if(Date.today().year() < goalYear)
                                          { 
                                                   AggregateResult  objAggrResult = (AggregateResult)goalAssetMappingBean.assetObj;
                                                   //groupedResults[0].get('aver')
                                                   /*if(objGoalAssetAssociation.asset__r.RecordType.Name.equals('Real Estate Assets'))
                                                      growthRate = double.valueOf(Label.RealEastateGrowthRate);//10
                                                   else
                                                      growthRate = FinancialUtil.calculateRate(FinancialUtil.calculateFutureValue(100,rateList,goalYear - currYear),
                                                                                                                           100,(goalYear- currYear));
                                                       */
                                                       String strSelectedRecordType = String.valueOf(objAggrResult.get('recordTypeName'));
                                                       if('Mutual Fund'.equals(strSelectedRecordType))
                                                       {
                                                              growthRate = FinancialUtil.calculateRate(FinancialUtil.calculateFutureValue(100,rateList,goalYear - currYear),
                                                                                                                           100,(goalYear- currYear));
                                                       }
                                                       else if(goalAssetMappingBean.description.equals('Stocks'))
                                                       {
                                                             // growthRate = double.valueOf(Label.StockGrowthRate);
                                                             system.debug('********globalAssumptions.Stock_Growth_Rate__c : 2********'+globalAssumptions.Stock_Growth_Rate__c);
                                                             growthRate = globalAssumptions.Stock_Growth_Rate__c;
                                                       }
                                                                     /* //Working code Manasi
                                                                     goalAssetMappingBean.goalYearValue = FinancialUtil.calculateCompound(goalAssetMappingBean.allocatedAmount,
                                                   (goalYear - currYear ), growthRate);
                                                   pvAmount = FinancialUtil.calculatePrincipal(targetAmount,(goalYear - currYear),growthRate);
                                                   if(remainingAmount >= pvAmount) {
                                                       remainingAmount = remainingAmount - pvAmount;
                                                       goalAssetMappingBean.remainingAmount = remainingAmount;
                                                       targetAmount = 0;
                                                   }else {
                                                       pvAmount = pvAmount - remainingAmount;
                                                       targetAmount =  FinancialUtil.calculateCompound(pvAmount,(goalYear - currYear ), growthRate);
                                                       goalAssetMappingBean.remainingAmount = 0;
                                                   }*/
                                                   
                                                   assetMaturedAmount = FinancialUtil.calculateCompound(goalAssetMappingBean.allocatedAmount,
                                                   (goalYear - currYear ), growthRate);
                                                   remainingAmount = assetMaturedAmount;
                                                                     goalAssetMappingBean.goalYearValue = assetMaturedAmount;
                                                                     goalAssetMappingBean.remainingAmount = remainingAmount;
                                             }
                                             
                                     }
                                }
                                if(remainingAmount > 0) 
								{
                                          if(targetAmount >= remainingAmount) {
                                              targetAmount = targetAmount - remainingAmount;
                                              
                                              isAssetAllocationStartYear = true; 
                                              goalAssetMappingBean.remainingAmount = 0;
                                              PrintSequence(goalYear,goalAssetMappingBean.description,goalAssetMappingBean.entityName);
                                          } else {
                                                //FS0168
                                                Double iTempTargetAmount =  targetAmount - remainingAmount;
                                              remainingAmount = remainingAmount - targetAmount;
                                              
                                              goalAssetMappingBean.remainingAmount = calculateUpdatedRemainingAmount(remainingAmount,goalFrequency);
                                              
                                              //Prevoius code: It is commented to display negative target amounts
                                              //targetAmount = 0;
                                              targetAmount = iTempTargetAmount;
                                              if(targetAmount < 0 && bean.goalEndYear == goalYear)
                                              	PrintSequence(goalYear,goalAssetMappingBean.description,goalAssetMappingBean.entityName);
                                          }
                                }
                        
                        }
                       
                        else if((Allocation_Action__c.getInstance('Action6').Action__c.equalsIgnoreCase(goalAssetMappingBean.action))) 
						{ 
                        } 
						else 
						{
                           System.debug('addSupport');
                       }
                   } else { //Since target amount for this goal year is zero, no need to check other assets
                       break;
                   }
                   //targetAmount Manasi Joshi
               }
              }catch(Exception ex) {
              throw new GeneralException('NewGoalService.applyAllocatedAssetsOnGoalAmount : Internal Error ' + ex.getMessage());
        }
        return targetAmount;
}